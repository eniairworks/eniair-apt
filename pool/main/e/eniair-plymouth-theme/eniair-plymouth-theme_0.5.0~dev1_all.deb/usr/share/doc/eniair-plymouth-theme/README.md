# eniair-plymouth-theme — EniairOS 起動スプラッシュ（Plymouth script テーマ）

0.5 計画の項目10「起動スプラッシュ＋EniairOS ロゴ」の土台。
バージョンは `0.5.0~dev1`（0.5 系の新パッケージ第1弾。eniair-shell の
`0.4.0~devN` とは別系統）。

## デザイン

- 白背景、中央やや上に「EniairOS」のワードマーク、画面下部に細い
  プログレスバー（高さ 3px・幅は画面幅の半分で上限 480px）。
- 塗りは淡い青（#A8C2D4）、受け皿はごく薄い灰（#E3E9ED）。枠線なし・
  蛍光色なし・低彩度。フェードイン（約0.75秒）＋進捗バーの素直な実装で、
  無理なアニメーションは入れない。
- パスワード要求時（暗号化ディスク等）は入力線＋ドット＋プロンプト文の
  最小表示に切り替わる。EniairOS の既定インストール（Calamares・
  暗号化なし）では出番はない。

## ファイル

| ファイル | 役割 |
|---|---|
| `eniair.plymouth` | テーマ定義（ModuleName=script） |
| `eniair.script` | script テーマ本体（API は trixie の plymouth 24 同梱の `script.script` 例に準拠） |
| `eniair-logo.png` | ワードマーク（暫定：Inter Light のテキスト描画。`generate-assets.py` で生成） |
| `progress-fill.png` / `progress-track.png` | バーの塗り／受け皿（無地 8x8 を Scale して使う） |
| `entry.png` / `bullet.png` | パスワード入力の線／ドット |
| `generate-assets.py` | アセット再生成用（chroot 内で実行。fonts-inter＋python3-pil が要る） |
| `debian/` | .deb 化（eniair-shell の debian/ と同じ流儀） |

## ロゴの差し替え（本人のロゴが届いたら）

1. 本人のロゴ PNG を `eniair-logo.png` に置き換える（透明背景・
   横幅 500px 前後を目安。ロゴドラフト `files/logo-drafts/` は叩き台で
   そのまま使わない）。
2. `debian/changelog` に版を上げて .deb を作り直し、リポジトリへ追加する。
3. スクリプト側の変更は不要（ファイル名と配置が同じならそのまま表示される）。

## 使い方（インストール後）

```sh
sudo apt install eniair-plymouth-theme
sudo plymouth-set-default-theme eniair
sudo update-initramfs -u
```

起動パラメータに `splash` が要る（次回 ISO からは既定で付く）。
postinst は update-alternatives への登録だけを行い、テーマの選択と
initramfs の再生成はしない（ISO ビルド時・chroot での失敗を避けるため）。

## 未検証・既知の制限

- Plymouth デーモンの実ブート表示はヘッドレスでは検証できない
  （DRM が要る）。QEMU／実機での目視は未検証。
- パスワードプロンプト文は `Image.Text` で描くため、initramfs 内で
  フォントが拾えない場合は文だけ表示されない（入力線とドットは出る）。
- バーの幅は画面幅の半分（上限 480px）で固定。超ワイド画面では
  相対的に細く見える。
